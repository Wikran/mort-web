@echo off
cd /d C:\DosProgram\Foxpro

echo SET SAFETY OFF > temp.prg
echo SET EXCLUSIVE OFF >> temp.prg
echo SET CODEPAGE TO 874 >> temp.prg
echo USE C:\DosProgram\LIFE\PASS.DBF >> temp.prg
echo COPY TO C:\DosProgram\LIFE\PASS.CSV DELIMITED >> temp.prg
echo QUIT >> temp.prg

foxpro.exe -t DO temp.prg

del temp.prg